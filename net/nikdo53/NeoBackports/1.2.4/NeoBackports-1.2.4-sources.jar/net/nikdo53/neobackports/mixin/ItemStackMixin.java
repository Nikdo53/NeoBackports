package net.nikdo53.neobackports.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.nikdo53.neobackports.extensions.ItemStackBackportExtension;
import net.nikdo53.neobackports.io.components.DataComponentType;
import net.nikdo53.neobackports.io.components.DataComponentRegistry;
import net.nikdo53.neobackports.registry.DeferredHolder;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.function.Supplier;

@Mixin(ItemStack.class)
public abstract class ItemStackMixin implements ItemStackBackportExtension {
    @Shadow
    public abstract void shrink(int decrement);

    @Shadow
    public abstract ItemStack copyWithCount(int count);

    @Shadow
    public abstract int getCount();

    @Shadow
    public abstract boolean hasTag();

    @Shadow
    @javax.annotation.Nullable
    public abstract CompoundTag getTag();

    @Shadow
    public abstract boolean is(Item item);

    @Shadow
    @javax.annotation.Nullable
    private CompoundTag tag;

    @Shadow
    public abstract CompoundTag save(CompoundTag compoundTag);

    @Shadow
    public abstract boolean isEmpty();

    @Override
    public @Nullable <T> T get(DataComponentType<? extends T> component) {
        return DataComponentRegistry.get((ItemStack) ((Object) this), component);
    }

    @Override
    public <T> T getOrDefault(DataComponentType<T> component, T defaultValue) {
        return DataComponentRegistry.getOrDefault((ItemStack) ((Object) this), component, defaultValue);
    }

    @Override
    public boolean has(DataComponentType<?> component) {
        return DataComponentRegistry.has((ItemStack) ((Object) this), component);
    }

    @Override
    public <T> void set(DataComponentType<? super T> componentType, @Nullable T value) {
        DataComponentRegistry.set((ItemStack) ((Object) this), componentType, value);
    }

    @Override
    public <T> void remove(DataComponentType<? super T> componentType) {
        DataComponentRegistry.remove((ItemStack) ((Object) this), componentType);
    }

    @Override
    public @Nullable <T> T get(Supplier<DataComponentType<? extends T>> component) {
        return get(component.get());
    }

    @Override
    public <T> T getOrDefault(Supplier<DataComponentType<T>> component, T defaultValue) {
        return getOrDefault(component.get(), defaultValue);
    }

    @Override
    public boolean has(Supplier<DataComponentType<?>> component) {
        return has(component.get());
    }

    @Override
    public <T> void set(Supplier<DataComponentType<T>> component, @Nullable T value) {
        set(component.get(), value);
    }

    @Override
    public <T> void remove(Supplier<DataComponentType<? extends T>> component) {
        remove(component.get());
    }

    @Override
    public ItemStack consumeAndReturn(int amount, @Nullable LivingEntity entity) {
        ItemStack itemstack = copyWithCount(amount);
        consume(amount, entity);
        return itemstack;
    }

    @Override
    public void consume(int amount, @Nullable LivingEntity entity) {
        if (entity == null || !(entity instanceof Player player && player.getAbilities().instabuild)) {
            shrink(amount);
        }
    }

    @Override
    public ItemStack transmuteCopy(ItemLike item) {
        return transmuteCopy(item, getCount());
    }

    @Override
    public ItemStack transmuteCopy(ItemLike item, int count) {
        ItemStack stack = new ItemStack(item, count);
        if (hasTag()) {
            stack.setTag(getTag().copy());
        }
        return stack;
    }

    @WrapMethod(method = "is(Lnet/minecraft/core/Holder;)Z")
    public boolean isFix(Holder<Item> item, Operation<Boolean> original){
        return is(item.value());
    }

    @Override
    public Tag save(HolderLookup.Provider levelRegistryAccess, Tag outputTag) {
        if (this.isEmpty())
            throw new IllegalStateException("Cannot encode empty ItemStack");

        return save(tag);
    }

    @Override
    public Tag save(HolderLookup.Provider levelRegistryAccess) {
        if (this.isEmpty())
            throw new IllegalStateException("Cannot encode empty ItemStack");

        return save(new CompoundTag());
    }
}
